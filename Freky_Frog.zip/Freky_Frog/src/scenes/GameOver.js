import Phaser from '../lib/phaser.js'

export default class GameOver extends Phaser.Scene
{
    constructor()
    {
        super('game-over')
    }

    preload()
    {
        this.load.image('title','assets/title.png')
    }

    create()
    {
        const width=this.scale.width
        const height=this.scale.height
        this.add.image(width*0.5, height*0.5, 'title')

        this.input.on('pointerdown', () => {this.scene.start('game')})

        this.sound.play('music')
    }
}